debugPrint(10,"CyberMod: shop module loaded")
questMod.module = questMod.module +1


