debugPrint(10,"CyberMod: mods module loaded")
questMod.module = questMod.module +1