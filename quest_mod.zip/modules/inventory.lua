debugPrint(10,"CyberMod: inventory module loaded")
questMod.module = questMod.module +1


