debugPrint(10,"CyberMod: UI beta module loaded")
questMod.module = questMod.module +1


