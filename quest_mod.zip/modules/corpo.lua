debugPrint(10,"CyberMod: Corpo module loaded")
questMod.module = questMod.module +1